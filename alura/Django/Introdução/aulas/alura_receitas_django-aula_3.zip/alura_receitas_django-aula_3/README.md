# Alura cursos online - Fundamentos Django 2: Uma aplicação web

Projeto da Alura cursos online, desenvolvido em Python3 com framework Django

## Projeto final aula 3

Nessa aula:

- Ajustamos os links da index, do logo através da template tag `url`;

- Criamos o `base.html` para usar as mesmas partes do HTML em diferentes páginas da aplicação;

- Evitamos código duplicado do `menu` e do `footer` criando e incluindo `partials`.


